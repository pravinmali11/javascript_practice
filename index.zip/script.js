document.addEventListener("DOMContentLoaded", function () {
  // Get the container where divs will be added
  const container = document.getElementById("container");

  // Function to create a new div with the necessary inputs and buttons
  function createNewDiv() {
    const newDiv = document.createElement("div");
    newDiv.classList.add("data-div");

    // Create a select dropdown for items
    const select = document.createElement("select");
    select.name = "choices";
    select.classList.add("choices");
    const options = [
      { value: "option1", text: "Select", price: 0 },
      { value: "option2", text: "HP", price: 100 },
      { value: "option3", text: "Dell", price: 120 },
      { value: "option4", text: "Lenovo", price: 110 },
    ];

    options.forEach((option) => {
      const optionElement = document.createElement("option");
      optionElement.value = option.value;
      optionElement.textContent = option.text;
      optionElement.dataset.price = option.price; // Store price in data-price attribute
      select.appendChild(optionElement);
    });

    // Create input for Price (set initially to 0)
    const priceInput = document.createElement("input");
    priceInput.type = "number";
    priceInput.placeholder = "Price";
    priceInput.value = 0;
    priceInput.readOnly = true; // Make the price input read-only

    // Create input for Quantity
    const quantityInput = document.createElement("input");
    quantityInput.type = "number";
    quantityInput.placeholder = "Quantity";
    quantityInput.value = 0;

    // Create input for Total
    const totalInput = document.createElement("input");
    totalInput.type = "number";
    totalInput.placeholder = "Total";
    totalInput.readOnly = true; // Make the total input read-only

    // Add an event listener to update the price and total based on selection
    select.addEventListener("change", function () {
      const selectedOption = select.options[select.selectedIndex];
      const price = parseFloat(selectedOption.dataset.price);
      priceInput.value = price;

      // Recalculate the total when the price or quantity changes
      calculateTotal(priceInput, quantityInput, totalInput);
    });

    // Add an event listener to update the total when quantity is entered
    quantityInput.addEventListener("input", function () {
      calculateTotal(priceInput, quantityInput, totalInput);
    });

    // Create a minus button to remove the div
    const minusBtn = document.createElement("button");
    minusBtn.classList.add("minus-btn");
    minusBtn.textContent = "-";
    minusBtn.addEventListener("click", function () {
      newDiv.remove();
    });

    // Create a plus button to add another div
    const plusBtn = document.createElement("button");
    plusBtn.classList.add("plus-btn");
    plusBtn.textContent = "+";
    plusBtn.addEventListener("click", function () {
      createNewDiv();
    });

    // Append all elements to the new div
    newDiv.appendChild(minusBtn);
    newDiv.appendChild(select);
    newDiv.appendChild(priceInput);
    newDiv.appendChild(quantityInput);
    newDiv.appendChild(totalInput);
    newDiv.appendChild(plusBtn);

    // Append the new div to the container
    container.appendChild(newDiv);
  }

  // Function to calculate the total (Price * Quantity)
  function calculateTotal(priceInput, quantityInput, totalInput) {
    const price = parseFloat(priceInput.value) || 0;
    const quantity = parseInt(quantityInput.value) || 0;
    totalInput.value = (price * quantity).toFixed(2); // Calculate and update total
  }

  // Add event listener to the first plus button
  const firstPlusButton = document.querySelector(".plus-btn");
  firstPlusButton.addEventListener("click", function () {
    createNewDiv();
  });

  // Add event listener to the first minus button
  const firstMinusButton = document.querySelector(".minus-btn");
  firstMinusButton.addEventListener("click", function () {
    firstMinusButton.closest(".data-div").remove();
  });
});
